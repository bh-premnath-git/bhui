import React, { useState, useCallback, useEffect } from "react";
import ReactFlow, { useNodesState, useEdgesState, addEdge, Controls, Connection, Edge, Node } from "reactflow";
import "reactflow/dist/style.css";
import ExpandableButton from '../../common/ExpandableButton';
import { buildData } from './staticData';
import TransformPopUp from "../../components/BuildPipeLineComps/TransformPopUp";
import Footer from "../../components/BuildPipeLineComps/Footer";
import { useDispatch, useSelector } from "react-redux";
import OrderPopUp from "../../components/BuildPipeLineComps/OrderPopUp";
import { CustomNodeData, ImageNode } from "../../components/BuildPipeLineComps/ImageNode";
import FilterPopUp from "../../components/BuildPipeLineComps/FilterPopUp";
import { Alert, IconButton, Popover, Snackbar, Tooltip } from "@mui/material";
import PlayPopUp from "./components/popups/PlayPopUp";
import Codepage from "../../components/BuildPipeLineComps/CodePage";
import CloseIcon from '@mui/icons-material/Close';
import { getConfig, getSource, setIsHover, setIsRun } from "../../redux/BuildPipeLineSlice";
import CustomEdge from "../../components/BuildPipeLineComps/customEdge";
import BuildPipePopup from "../../components/BuildPipeLineComps/BuildPipePopup";
import ControlPanel from "../../components/BuildPipeLineComps/ControlPanel";
import { RootState } from "@/store/store";
import BuildPipeLineFlow from "@/pages/buildPipeLine/buildPipeLineFlow";

export default function BuildDataPipeLine() {
    const [isPopupOpen, setIsPopupOpen] = useState<boolean>(false);
    const [selectedNodeData, setSelectedNodeData] = useState<CustomNodeData | null>(null);
    const { isHover, selectedOption }: any = useSelector((state: RootState) => state.buildPipeLineApi);
    const [isButtonClicked, setIsButtonClicked] = useState(false);
    // const [open, setOpen] = useState(false);
    const [open1, setOpen1] = useState(false);
    const dispatch = useDispatch();
    const isToggled = useSelector((state: RootState) => state.toggle.isToggled);
    const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
    const open = Boolean(anchorEl);
    const [isOverlayOpen, setIsOverlayOpen] = useState(false);
    useEffect(() => {
        dispatch(getConfig({ connection_type: 'source' }));
        dispatch(getSource({ offset: 0, limit: 10, order_desc: false }));
        console.log('first' + selectedOption)
    }, [dispatch]);



    const handleClose1 = () => {
        setOpen1(false);
    };

    const handleButtonClick = () => {
        dispatch(setIsRun(true))
        setIsButtonClicked(true);
        setIsPopupOpen(true);
    };

    const closePopup = () => {
        setIsPopupOpen(false);
        setIsButtonClicked(false);
        dispatch(setIsHover(false))
    };

    const handleOverlayOpen = () => {
        setIsOverlayOpen(true);
    };
    const handleOverlayClose = () => {
        setIsOverlayOpen(false);
    };



    return (
        <div style={{ position: 'relative', height: '100vh' }}>
            {isToggled ? (
                <Codepage />
            ) : (
                <>
                   <BuildPipeLineFlow />
                    {selectedOption?.label?.toLowerCase().trim() === "transform" &&
                        <TransformPopUp isOpen={isHover} onClose={closePopup} nodeData={selectedNodeData} />
                    }

                    {selectedOption?.label?.toLowerCase().trim() === "filter" &&
                        <FilterPopUp isOpen={isHover} onClose={closePopup} nodeData={selectedNodeData} />
                    }
                    {selectedOption?.label?.toLowerCase().trim() === "source" &&
                        <OrderPopUp isOpen={isHover} onClose={closePopup} nodeData={selectedNodeData} />
                    }
                </>
            )}
            <Footer com={<ControlPanel
                isButtonClicked={isButtonClicked}
                handleButtonClick={handleButtonClick}
                isPopupOpen={isPopupOpen}
                closePopup={closePopup}
                open1={open1}
                handleClose1={handleClose1}
                handleClose1Icon={handleClose1}
            />} />
            <div style={{
                position: 'fixed',
                top: '75px', // Adjust as needed to be above the footer
                right: '1%',
                zIndex: 1
            }}>
                <Tooltip title="" placement="top">
                    <IconButton
                        style={{
                            borderRadius: '50%',
                            color: 'white',
                            width: '80px',
                            height: '80px',
                            boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
                        }}
                        onClick={handleOverlayOpen}
                    >
                        <img src="/assets/buildPipeline/bighammer.png" alt="bighammer" width={80} />
                    </IconButton>
                </Tooltip>
            </div>
            {isOverlayOpen && (
                <div
                    style={{
                        position: 'fixed',
                        top: 0,
                        right: 0,
                        width: '400px',
                        height: '100%',
                        backgroundColor: 'white',
                        zIndex: 2,
                        color: 'black',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'start',
                        alignItems: 'center',
                        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
                    }}
                >

                    <BuildPipePopup closePopup={handleOverlayClose} />
                </div>

            )}
        </div>
    );
}