export const snowflakeData={
    "documentationUrl": "N/A",
    "connectionSpecification": {
      "$schema": "http://json-schema.org/draft-07/schema#",
      "title": "Snowflake Source Spec",
      "type": "object",
      "required": [
        "host",
        "role",
        "warehouse",
        "database"
      ],
      "properties": {
        "credentials": {
          "title": "Authorization Method",
          "type": "object",
          "oneOf": [
            {
              "type": "object",
              "title": "OAuth2.0",
              "order": 0,
              "required": [
                "client_id",
                "client_secret",
                "auth_type"
              ],
              "bh_hidden": true,
              "properties": {
                "auth_type": {
                  "type": "string",
                  "const": "OAuth",
                  "order": 0
                },
                "client_id": {
                  "type": "string",
                  "title": "Client ID",
                  "description": "The Client ID of your Snowflake developer application.",
                  "bh_secret": true,
                  "order": 1
                },
                "client_secret": {
                  "type": "string",
                  "title": "Client Secret",
                  "description": "The Client Secret of your Snowflake developer application.",
                  "bh_secret": true,
                  "order": 2
                },
                "access_token": {
                  "type": "string",
                  "title": "Access Token",
                  "description": "Access Token for making authenticated requests.",
                  "bh_secret": true,
                  "order": 3
                },
                "refresh_token": {
                  "type": "string",
                  "title": "Refresh Token",
                  "description": "Refresh Token for making authenticated requests.",
                  "bh_secret": true,
                  "order": 4
                }
              }
            },
            {
              "title": "Key Pair Authentication",
              "type": "object",
              "order": 1,
              "required": [
                "username",
                "private_key"
              ],
              "properties": {
                "auth_type": {
                  "type": "string",
                  "const": "Key Pair Authentication",
                  "order": 0
                },
                "username": {
                  "description": "The username you created to allow BigHammer to access the database.",
                  "examples": [
                    "BH_USER"
                  ],
                  "type": "string",
                  "title": "Username",
                  "order": 1
                },
                "private_key": {
                  "type": "string",
                  "title": "Private Key",
                  "description": "RSA Private key to use for Snowflake connection.",
                  "multiline": true,
                  "bh_secret": true,
                  "order": 2
                },
                "private_key_password": {
                  "type": "string",
                  "title": "Passphrase",
                  "description": "Passphrase for private key",
                  "bh_secret": true,
                  "order": 3
                }
              }
            },
            {
              "title": "Username and Password",
              "type": "object",
              "required": [
                "username",
                "password",
                "auth_type"
              ],
              "order": 2,
              "properties": {
                "auth_type": {
                  "type": "string",
                  "const": "username/password",
                  "order": 0
                },
                "username": {
                  "description": "The username you created to allow BigHammer to access the database.",
                  "examples": [
                    "BH_USER"
                  ],
                  "type": "string",
                  "title": "Username",
                  "order": 1
                },
                "password": {
                  "description": "The password associated with the username.",
                  "type": "string",
                  "bh_secret": true,
                  "title": "Password",
                  "order": 2
                }
              }
            }
          ],
          "order": 0
        },
        "host": {
          "description": "The host domain of the snowflake instance (must include the account, region, cloud environment, and end with snowflakecomputing.com).",
          "examples": [
            "accountname.us-east-2.aws.snowflakecomputing.com"
          ],
          "type": "string",
          "title": "Account Name",
          "order": 1
        },
        "role": {
          "description": "The role you created for BigHammer to access Snowflake.",
          "examples": [
            "BH_ROLE"
          ],
          "type": "string",
          "title": "Role",
          "order": 2
        },
        "warehouse": {
          "description": "The warehouse you created for BigHammer to access data.",
          "examples": [
            "BH_WAREHOUSE"
          ],
          "type": "string",
          "title": "Warehouse",
          "order": 3
        },
        "database": {
          "description": "The database you created for BigHammer to access data.",
          "examples": [
            "BH_DATABASE"
          ],
          "type": "string",
          "title": "Database",
          "order": 4
        },
        "schema": {
          "description": "The source Snowflake schema tables. Leave empty to access tables from multiple schemas.",
          "examples": [
            "BH_SCHEMA"
          ],
          "type": "string",
          "title": "Schema",
          "order": 5
        },
        "jdbc_url_params": {
          "description": "Additional properties to pass to the JDBC URL string when connecting to the database formatted as 'key=value' pairs separated by the symbol '&'. (example: key1=value1&key2=value2&key3=value3).",
          "title": "JDBC URL Params",
          "type": "string",
          "order": 6
        }
      }
    },
    "advanced_auth": {
      "auth_flow_type": "oauth2.0",
      "predicate_key": [
        "credentials",
        "auth_type"
      ],
      "predicate_value": "OAuth",
      "oauth_config_specification": {
        "oauth_user_input_from_connector_config_specification": {
          "type": "object",
          "properties": {
            "host": {
              "type": "string",
              "path_in_connector_config": [
                "host"
              ]
            },
            "role": {
              "type": "string",
              "path_in_connector_config": [
                "role"
              ]
            }
          }
        },
        "complete_oauth_output_specification": {
          "type": "object",
          "properties": {
            "access_token": {
              "type": "string",
              "path_in_connector_config": [
                "credentials",
                "access_token"
              ]
            },
            "refresh_token": {
              "type": "string",
              "path_in_connector_config": [
                "credentials",
                "refresh_token"
              ]
            }
          }
        },
        "complete_oauth_server_input_specification": {
          "type": "object",
          "properties": {
            "client_id": {
              "type": "string"
            },
            "client_secret": {
              "type": "string"
            }
          }
        },
        "complete_oauth_server_output_specification": {
          "type": "object",
          "properties": {
            "client_id": {
              "type": "string",
              "path_in_connector_config": [
                "credentials",
                "client_id"
              ]
            },
            "client_secret": {
              "type": "string",
              "path_in_connector_config": [
                "credentials",
                "client_secret"
              ]
            }
          }
        }
      }
    }
  }
  